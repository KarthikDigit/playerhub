package com.playerhub;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.mancj.slideup.SlideUp;
import com.mancj.slideup.SlideUpBuilder;
import com.playerhub.ui.base.BaseActivity;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View slideView = findViewById(R.id.slideView);


        final SlideUp slideUp = new SlideUpBuilder(slideView)
//                .withStartState(SlideUp.State.SHOWED)
                .withStartGravity(Gravity.TOP)

                .withSlideFromOtherView(findViewById(R.id.rootview))
                .withGesturesEnabled(true)
                //.withHideSoftInputWhenDisplayed()
                .withInterpolator(new LinearInterpolator())
                //.withAutoSlideDuration()
                .withLoggingEnabled(true)
                //.withTouchableAreaPx()
//                .withTouchableAreaDp(100)
                .withListeners()
                //.withSavedState()
                .build();


//        findViewById(R.id.rootview).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                slideUp.show();
//            }
//        });
    }
}
