package com.playerhub.ui.dashboard.chat;

import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;
import com.playerhub.R;
import com.playerhub.preference.Preferences;
import com.playerhub.ui.dashboard.messages.Messages;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class ChatRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_ME = 1;
    private static final int VIEW_TYPE_OTHER = 2;

    private List<Messages> mChats;

    public ChatRecyclerAdapter(List<Messages> chats) {
        mChats = chats;
    }

    public void add(Messages chat) {
        mChats.add(chat);
        notifyItemInserted(mChats.size() - 1);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        RecyclerView.ViewHolder viewHolder = null;
        switch (viewType) {
            case VIEW_TYPE_ME:
                View viewChatMine = layoutInflater.inflate(R.layout.item_chat_mine, parent, false);
                viewHolder = new MyChatViewHolder(viewChatMine);
                break;
            case VIEW_TYPE_OTHER:
                View viewChatOther = layoutInflater.inflate(R.layout.item_chat_other, parent, false);
                viewHolder = new OtherChatViewHolder(viewChatOther);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (TextUtils.equals(mChats.get(position).getSender(),
                Preferences.INSTANCE.getMsgUserId())) {
            configureMyChatViewHolder((MyChatViewHolder) holder, position);
        } else {
            configureOtherChatViewHolder((OtherChatViewHolder) holder, position);
        }
    }

    private void configureMyChatViewHolder(MyChatViewHolder myChatViewHolder, int position) {
        Messages chat = mChats.get(position);

        String alphabet = chat.getName() != null && chat.getName().length() > 0 ? chat.getName().substring(0, 1) : "";

        myChatViewHolder.txtChatMessage.setText(chat.getMsg());
        myChatViewHolder.txtUserAlphabet.setText(alphabet);
        myChatViewHolder.txtTime.setText(getDate(chat.getTimestamp()));
    }

    private void configureOtherChatViewHolder(OtherChatViewHolder otherChatViewHolder, int position) {
        Messages chat = mChats.get(position);

        String alphabet = chat.getName() != null && chat.getName().length() > 0 ? chat.getName().substring(0, 1) : "";

        otherChatViewHolder.txtChatMessage.setText(chat.getMsg());
        otherChatViewHolder.txtUserAlphabet.setText(alphabet);
        otherChatViewHolder.txtTime.setText(getDate(chat.getTimestamp()));
    }

    private String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        return DateFormat.format("hh:mm a", cal).toString();
//        return DateFormat.format("dd-MMM-yyyy hh:mm a", cal).toString();
    }

    @Override
    public int getItemCount() {
        if (mChats != null) {
            return mChats.size();
        }
        return 0;
    }

    @Override
    public int getItemViewType(int position) {
        if (TextUtils.equals(mChats.get(position).getSender(),
                Preferences.INSTANCE.getMsgUserId())) {
            return VIEW_TYPE_ME;
        } else {
            return VIEW_TYPE_OTHER;
        }
    }

    private static class MyChatViewHolder extends RecyclerView.ViewHolder {
        private TextView txtChatMessage, txtUserAlphabet, txtTime;

        public MyChatViewHolder(View itemView) {
            super(itemView);
            txtChatMessage = (TextView) itemView.findViewById(R.id.text_view_chat_message);
            txtTime = (TextView) itemView.findViewById(R.id.text_view_chat_time);
            txtUserAlphabet = (TextView) itemView.findViewById(R.id.text_view_user_alphabet);
        }
    }

    private static class OtherChatViewHolder extends RecyclerView.ViewHolder {
        private TextView txtChatMessage, txtUserAlphabet, txtTime;

        public OtherChatViewHolder(View itemView) {
            super(itemView);
            txtTime = (TextView) itemView.findViewById(R.id.text_view_chat_time);
            txtChatMessage = (TextView) itemView.findViewById(R.id.text_view_chat_message);
            txtUserAlphabet = (TextView) itemView.findViewById(R.id.text_view_user_alphabet);
        }
    }
}
