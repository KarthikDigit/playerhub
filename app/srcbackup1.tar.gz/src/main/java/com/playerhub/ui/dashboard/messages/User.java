package com.playerhub.ui.dashboard.messages;

import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mikepenz.fastadapter.FastAdapter;
import com.mikepenz.fastadapter.items.AbstractItem;
import com.playerhub.R;
import com.playerhub.notification.Constants;
import com.playerhub.preference.Preferences;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class User extends AbstractItem<User, User.ViewHolder> implements Serializable {

    private static final String TAG = "User";

    public String name;
    public long notification;
    public String team;
    //    public String type;
    //    public String description;
//    public String date_time;
//    public String count;
    public String id;
    public String icon;
    public long connection;

    //The unique ID for this type of item
    @Override
    public int getType() {
        return R.id.root;
    }

    //The layout to be used for this type of item
    @Override
    public int getLayoutRes() {
        return R.layout.message_item;
    }

    @Override
    public ViewHolder getViewHolder(@NonNull View v) {
        return new ViewHolder(v);
    }


    /**
     * our ViewHolder
     */
    protected static class ViewHolder extends FastAdapter.ViewHolder<User> {

        @BindView(R.id.icon)
        CircleImageView icon;
        @BindView(R.id.date_time)
        TextView dateTime;
        @BindView(R.id.name)
        TextView name;
        @BindView(R.id.description)
        TextView description;
        @BindView(R.id.count)
        TextView count;
        @BindView(R.id.count_lay)
        RelativeLayout countLay;
        @BindView(R.id.root)
        RelativeLayout root;

        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @Override
        public void bindView(final User item, List<Object> payloads) {

//            StringHolder.applyToOrHide(item.description, description);

//            description.setText(item.team);
            count.setText(item.notification + "");
            name.setText(item.name);
//            dateTime.setText(item.date_time);

            countLay.setVisibility(View.VISIBLE);
            if (item.notification == 0) {
                countLay.setVisibility(View.INVISIBLE);
            }

//            final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child(Constants.ARG_CONVERSATION).child(Preferences.INSTANCE.getMsgUserId()).getRef();
            Handler uiHandler = new Handler(Looper.getMainLooper());
            uiHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (item.icon != null && item.icon.length() > 0)
//                        new Picasso.Builder(itemView.getContext())
//                                .downloader(new OkHttp3Downloader(itemView.getContext(), Integer.MAX_VALUE))
//                                .build()
//                                .load(item.icon)
//                                .into(icon);
                        Picasso.get().load(item.icon).placeholder(R.mipmap.ic_launcher).resize(120, 120).into(icon);

                }
            });


//            Observable.create(new ObservableOnSubscribe<Long>() {
//
//                @Override
//                public void subscribe(final ObservableEmitter<Long> e) {
//
//                    final List<String> users = new ArrayList<>();
//                    users.add(item.id);
//                    users.add(Preferences.INSTANCE.getMsgUserId());
//                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                            long c = 0;
//
//                            for (DataSnapshot dataSnapshotChild : dataSnapshot.getChildren()) {
//                                Conversations value = dataSnapshotChild.getValue(Conversations.class);
//
//                                try {
//                                    if (value != null && value.getUsers().containsAll(users)) {
//
//                                        long v = value.getUnread();
//                                        c += v;
//                                    }
//                                } catch (NullPointerException e) {
//
//                                }
//
//                            }
//
//                            e.onNext(c);
//
//
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError databaseError) {
//
//
//                            Log.e(TAG, "onCancelled: message count " + databaseError.getMessage());
//
//                        }
//                    });

//
//                }
//            }).subscribeOn(Schedulers.newThread()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<Long>() {
//                @Override
//                public void onSubscribe(Disposable d) {
//
//                }
//
//                @Override
//                public void onNext(final Long value) {
//
//                    count.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            count.setText(String.format(Locale.ENGLISH, "%d", value));
//                            countLay.post(new Runnable() {
//                                @Override
//                                public void run() {
//                                    countLay.setVisibility(value > 0 ? View.VISIBLE : View.INVISIBLE);
//                                }
//                            });
//
//                        }
//                    });
//
//                }
//
//                @Override
//                public void onError(Throwable e) {
//
//                }
//
//                @Override
//                public void onComplete() {
//
//                }
//            });


//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//
//                    Handler handler = new Handler(Looper.getMainLooper());
//                    handler.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            final List<String> users = new ArrayList<>();
//                            users.add(item.id);
//                            users.add(Preferences.INSTANCE.getMsgUserId());
//                            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                                    long c = 0;
//
//                                    for (DataSnapshot dataSnapshotChild : dataSnapshot.getChildren()) {
//                                        Conversations value = dataSnapshotChild.getValue(Conversations.class);
//
//                                        try {
//                                            if (value != null && value.getUsers().containsAll(users)) {
//
//                                                long v = value.getUnread();
//                                                c += v;
//                                            }
//                                        } catch (NullPointerException e) {
//
//                                        }
//
//                                    }
//
//                                    final long finalC = c;
//                                    count.post(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            count.setText(String.format(Locale.ENGLISH, "%d", finalC));
//                                            countLay.post(new Runnable() {
//                                                @Override
//                                                public void run() {
//                                                    countLay.setVisibility(finalC > 0 ? View.VISIBLE : View.INVISIBLE);
//                                                }
//                                            });
//
//                                        }
//                                    });
//
//
//                                }
//
//                                @Override
//                                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//
//                                    Log.e(TAG, "onCancelled: message count " + databaseError.getMessage());
//
//                                }
//                            });
//
//
//                        }
//                    });
//
//                }
//            }).start();


        }

        @Override
        public void unbindView(User item) {
            description.setText(null);
            count.setText(null);
            dateTime.setText(null);
            name.setText(null);
        }
    }


}