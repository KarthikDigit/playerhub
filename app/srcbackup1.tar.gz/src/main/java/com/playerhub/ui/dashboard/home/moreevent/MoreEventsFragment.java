package com.playerhub.ui.dashboard.home.moreevent;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.playerhub.R;
import com.playerhub.common.ActivityStats;
import com.playerhub.network.RetrofitAdapter;
import com.playerhub.network.response.EventListApi.EventListResponseApi;
import com.playerhub.network.response.EventListApi.UpcommingEvent;
import com.playerhub.preference.Preferences;
import com.playerhub.recyclerHelper.SimpleDividerItemDecoration;
import com.playerhub.ui.base.BaseFragment;
import com.playerhub.ui.dashboard.DashBoardActivity;
import com.playerhub.ui.dashboard.home.EventsAdapter;
import com.playerhub.ui.dashboard.home.eventdetails.EventDetailsActivity;
import com.playerhub.ui.dashboard.home.eventdetails.EventDetailsFragment;
import com.vlonjatg.progressactivity.ProgressRelativeLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import io.reactivex.Observable;

public class MoreEventsFragment extends BaseFragment implements EventsAdapter.OnItemClickListener<UpcommingEvent> {
    private static final String TAG = "MoreEventsActivity";

    @BindView(R.id.eventsView)
    RecyclerView eventsView;
    @BindView(R.id.progressActivity)
    ProgressRelativeLayout progressActivity;
    Unbinder unbinder;
    @BindView(R.id.back)
    ImageView back;

    private EventsAdapter eventsAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_more_events, container, false);

        unbinder = ButterKnife.bind(this, view);


        eventsAdapter = new EventsAdapter(getContext(), new ArrayList<UpcommingEvent>(), this);

        eventsView.setLayoutManager(new LinearLayoutManager(getContext()));

        eventsView.setAdapter(eventsAdapter);

        eventsView.addItemDecoration(new SimpleDividerItemDecoration(getContext()));

        callEventListApi();

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick({R.id.eventsView, R.id.progressActivity})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.eventsView:
                break;
            case R.id.progressActivity:
                break;
        }
    }

    private void callEventListApi() {

        setProgressActivity(ActivityStats.LOADING);

        Observable observable = RetrofitAdapter.getNetworkApiServiceClient().fetchAllEvents(Preferences.INSTANCE.getAuthendicate());

        setObservableAndObserver(observable, new Observers<EventListResponseApi>(getContext(), false) {

            @Override
            protected void onSuccess(EventListResponseApi response) {
                setProgressActivity(ActivityStats.CONTENT);
                setData(response);
            }

            @Override
            protected void onFail(Throwable e) {
                setProgressActivity(ActivityStats.ERROR);
            }
        });

    }


    private void setData(EventListResponseApi response) {

        if (response.getSuccess()) {

            List<UpcommingEvent> todayEvent = response.getData().getTodayEvents();
            List<UpcommingEvent> upcommingEvents = response.getData().getUpcommingEvents();


            Log.e(TAG, "setData: " + todayEvent.size() + "  up " + upcommingEvents.size());


            List<UpcommingEvent> eventList = new ArrayList<>();
            eventList.addAll(todayEvent);
            eventList.addAll(upcommingEvents);

            eventsAdapter.updateList(eventList);

        } else {
            setProgressActivity(ActivityStats.EMPTY);
        }
    }

    @Override
    public void OnItemClick(View view, UpcommingEvent datum, int position) {
//        startActivity(EventDetailsActivity.getIntent(getContext(), datum.getId()));

        if (getActivity() instanceof DashBoardActivity) {

            ((DashBoardActivity) getActivity()).callFragmentFromOutSide(EventDetailsFragment.getInstance(datum.getId()));
        }

    }


    private void setProgressActivity(ActivityStats activityStats) {


        switch (activityStats) {
            case LOADING:
                showProgress(progressActivity);
                break;
            case EMPTY:
                showEmpty(progressActivity,
                        "No Data",
                        "There is no event available");

                break;
            case ERROR:
                showError(progressActivity,
                        "Error",
                        "",
                        "Try Again", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                callEventListApi();
                            }
                        });

                break;
            case CONTENT:
                showContent(progressActivity);
                break;
        }

    }

    @OnClick(R.id.back)
    public void onViewClicked() {

        if (getActivity() != null)
            getActivity().onBackPressed();

    }
}
