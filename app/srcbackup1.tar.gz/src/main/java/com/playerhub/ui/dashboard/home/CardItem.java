package com.playerhub.ui.dashboard.home;

public class CardItem {

    private String title;

    public CardItem(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
