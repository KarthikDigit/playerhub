package com.playerhub.common;

public enum ActivityStats {

    ERROR, LOADING, CONTENT, EMPTY;

}
