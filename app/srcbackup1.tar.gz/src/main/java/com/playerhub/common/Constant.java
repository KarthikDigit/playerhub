package com.playerhub.common;

public class Constant {
    //    public static final String API_BASE_URL = "http://159.89.172.141/api/";
//    public static final String API_BASE_URL = "http://192.168.0.134/api/";
    public static final String API_BASE_URL = "http://api.playerhub.io/api/";
//    public static final String API_BASE_URL = "http://api.playerhub.io/api/";
}
